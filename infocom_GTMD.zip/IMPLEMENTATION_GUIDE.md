# Implementation Guide — Incentive–Learning Frontier paper (for Prashant)

This is the build-and-run companion to `main_full.tex`. The paper's theory is written; your job is mostly **running and verifying**, not designing. The single experiment that the paper stands on is the $\rho$-vs-$L$ sweep (Fig. 1). Everything else supports it.

Honest scope note: the Bayesian estimator and the (min,+) service-curve work stay **out** of this paper. They are the journal extension. Do not let them onto the conference critical path.

---

## 0. The 3-day plan (what to actually do, in order)

**Day 1 — theory check, no code.** Read the four proofs in `main_full.tex` (Sec. IV–VI + Appendices A–C) and stress the flagged soft steps. In priority order:
1. **Lemma 1 (Appendix C)** — the spine. If binding frequency $\rho$ secretly depends on epoch length $L$, the whole frontier collapses to prior work. Convince yourself the ergodic/stationarity argument holds for your traffic model, or find the counterexample now.
2. **Theorem 2 envelope step (Appendix A)** — that the welfare-aligned manipulation term vanishes on interior slots. Check the KKT decomposition line by line.
3. **Theorem 3 lower bound (Appendix B)** — keep it class-restricted (epoch-frozen, monotone allocator). Do not let it claim universality.

**Day 2 — the one experiment.** In the 5G-LENA setup you already built, implement the RL scheduler hook + $\rho$ logging + the sweep, and produce Fig. 1. This is the whole empirical contribution.

**Day 3 — writing.** Fill the abstract numbers, the results paragraph (H1–H3), Fig. 1, and finish intro/related-work prose. Verify every bibliography entry (I filled them from memory; confirm DOIs, years, page numbers).

---

## 1. Two API caveats to resolve before coding (30 min)

These are the only real unknowns. Resolve both first.

1. **Does ns3-ai build against ns-3.46?** We deferred this. Clone the actively maintained fork and configure:
   ```bash
   cd /work/ns-3-dev/contrib
   git clone https://github.com/DEFIANCE-project/ns3-ai.git ai      # dir name "ai"
   cd /work/ns-3-dev && ./ns3 configure --enable-examples --enable-tests
   ```
   If it fails the same way `opengym` did (CMake target/version drift), drop to the ns-3 version ns3-ai's README pins and re-pair `nr` accordingly. Confirm before building the scheduler.

2. **Exact NR scheduler method to override.** The base-class method name has shifted across `nr` releases. In `contrib/nr` v4.1.1, find the per-slot DL assignment entry point:
   ```bash
   cd /work/ns-3-dev/contrib/nr
   grep -rn "AssignDlRBG\|AssignDlResource\|DoSchedDlTriggerReq\|ScheduleDl" model/ | head
   ls model/ | grep -i sched
   ```
   The OFDMA schedulers (`nr-mac-scheduler-ofdma*.{h,cc}`) and the base `nr-mac-scheduler-ns3.{h,cc}` are where the overridable RBG-assignment virtual lives. Note the exact signature; the snippet below marks where to paste it.

---

## 2. Repository layout

```
ns-3-dev/contrib/nr/model/
  nr-mac-scheduler-rl.h         # NEW: your scheduler subclass
  nr-mac-scheduler-rl.cc        # NEW
ns-3-dev/scratch/
  rl-slicing-scenario.cc        # NEW: gNBs/UEs/EPC/traffic + tenant tagging
python/
  prb_env.py                    # Gymnasium wrapper over ns3-ai shared memory
  mechanism.py                  # per-epoch weights + Myerson payments
  train_frozen.py               # SB3 PPO with epoch-frozen schedule
  adversary.py                  # tabular Q-learning misreporting tenant
  sweep.py                      # loops over (L, eta); collects slack, rho, regret
  plot_frontier.py              # Fig. 1
```

---

## 3. C++ — the RL scheduler subclass (the monotone inner allocator)

This is the load-bearing piece: **monotonicity of the allocator in the weight is what gives DSIC** (Assumption 2 / Theorem 1). Confirm the base-class method name from step 1.2 before pasting the override.

```cpp
// nr-mac-scheduler-rl.h  (illustrative; confirm base class + override signature)
#ifndef NR_MAC_SCHEDULER_RL_H
#define NR_MAC_SCHEDULER_RL_H
#include "nr-mac-scheduler-ofdma-rr.h"   // derive from an OFDMA scheduler
namespace ns3 {

class NrMacSchedulerRl : public NrMacSchedulerOfdmaRR
{
public:
  static TypeId GetTypeId (void);
  NrMacSchedulerRl ();

protected:
  // <<< CONFIRM exact virtual name/signature in nr v4.1.1 (step 1.2) >>>
  // Override the per-slot DL RBG assignment so it consumes m_w and fills greedily.
  // e.g.:  void AssignDlRBG (PointInFTPlane& ..., const std::vector<UePtr>& ues) override;

private:
  std::vector<double> m_w;          // per-tenant weights, frozen per epoch (set from Python)
  std::vector<uint8_t> m_bind;      // per-tenant binding indicator for this window
  void GreedyFillByWeight (/* slot ctx, ue list, B */);
  void SyncWithAgent ();            // ns3-ai: push state, block, read weights
};

} // namespace ns3
#endif
```

```cpp
// nr-mac-scheduler-rl.cc  — the monotone allocator (core logic)
//
// Weighted greedy fill:
//   1) give every floor-constrained UE its floor f_i first;
//      if the floor (not the UE's own BSR) is what limits it, set m_bind[i]=1.
//   2) sort the remaining UEs by m_w[i] descending.
//   3) hand out remaining RBGs in that order, each UE capped by its BSR demand,
//      until PRBs (B) are exhausted.
//
// MONOTONICITY INVARIANT (assert this in a unit test, see Sec. 7):
//   holding all other weights and inputs fixed, increasing m_w[i]
//   must give weakly more RBGs to UE i. The sort-by-weight fill guarantees this.
void NrMacSchedulerRl::GreedyFillByWeight (/* ... */)
{
  // (1) floors
  // for each constrained ue i: assign f_i; m_bind[i] = (floor_is_binding ? 1 : 0);
  // (2) order by weight desc
  // (3) distribute leftover RBGs by weight order, capped by BSR, until B exhausted
}
```

> Why subclass instead of `Simulator::Schedule`: the NR PHY already fires the scheduler every slot. Your override **is** the per-step callback; you inherit slot timing for free. You only touch `Simulator::Schedule` for scenario events (ramping load, moving a UE), never for the control loop.

---

## 4. C++/Python — the ns3-ai shared-memory contract

State pushed to Python, action (weights) read back. Keep it a flat POD struct on both sides.

```cpp
// shared structs (mirror exactly in Python via the ns3-ai binding)
#define MAX_UE 64
struct RlEnvState {     // -> Python
  uint32_t nUe;
  double cqi[MAX_UE];
  double bsr[MAX_UE];       // buffer status, bytes
  double holDelay[MAX_UE]; // head-of-line delay
  double thrAvg[MAX_UE];   // recent throughput
  uint8_t tenantOf[MAX_UE];// UE -> tenant id
  uint8_t bind[MAX_UE];    // binding indicator this window
};
struct RlAct {          // <- Python
  double weight[MAX_UE];   // per-tenant weight (>=0), broadcast to that tenant's UEs
};
```

---

## 5. Python — Gymnasium env + epoch-frozen PPO (the mechanism)

The **epoch-frozen schedule is the mechanism, not an optimization detail**: with `n_steps=L`, SB3 holds policy parameters fixed while collecting one epoch of rollout, then updates once. That is exactly the within-epoch freeze that buys exact DSIC (Theorem 1) and the $O(1/L)$ marginal-influence property (Assumption 3).

```python
# prb_env.py
import gymnasium as gym
import numpy as np
# from py_interface import Ns3AIRL, Init, FreeMemory   # confirm import path for installed ns3-ai

N = 4  # tenants

class PrbEnv(gym.Env):
    def __init__(self, n_tenants=N):
        self.N = n_tenants
        # state: [cqi, bsr, holDelay, thrAvg] per tenant (aggregate UE->tenant)
        self.observation_space = gym.spaces.Box(0, np.inf, shape=(4*self.N,), dtype=np.float32)
        self.action_space      = gym.spaces.Box(0.0, 1.0, shape=(self.N,), dtype=np.float32)
        # bind to ns3-ai shared-memory pool here

    def reset(self, *, seed=None, options=None):
        return self._read_state(), {}

    def step(self, action):
        w = monotone_weights(action, self._last_reports)   # enforce Myerson monotonicity
        self._write_action(w)                               # weights -> C++ scheduler
        obs = self._read_state()
        reward = self._reward(obs)                          # throughput - lambda*delay - penalty*viol
        terminated = self._episode_done()
        return obs, reward, terminated, False, {}
```

```python
# enforce that weight is nondecreasing in a tenant's OWN report (Myerson monotonicity).
# isotonic projection onto the order induced by the reports:
def monotone_weights(raw, reports):
    order = np.argsort(reports)
    iso   = np.maximum.accumulate(np.asarray(raw)[order])
    out   = np.empty_like(iso); out[order] = iso
    return out
```

```python
# train_frozen.py
from stable_baselines3 import PPO
from prb_env import PrbEnv

L = 200            # epoch length in slots  (THE swept knob)
K = 500            # number of epochs
env = PrbEnv()
# n_steps = L  ==>  params frozen within each epoch, updated once per epoch (the freeze)
model = PPO("MlpPolicy", env, n_steps=L, batch_size=L, gamma=0.99, verbose=1)
model.learn(total_timesteps=K * L)
model.save(f"ppo_frozen_L{L}")
```

---

## 6. Python — mechanism layer (per-epoch weights + Myerson payments)

```python
# mechanism.py
import numpy as np

def critical_value_payment(report_i, others, alloc_fn, grid_n=64):
    """Myerson threshold payment from the FROZEN per-epoch allocation rule:
       p_i = theta_i * a_i(theta_i) - \int_0^{theta_i} a_i(z) dz."""
    grid = np.linspace(0.0, report_i, grid_n)
    a = np.array([alloc_fn(z, others) for z in grid])   # a_i(z): aggregate alloc if i reports z
    return report_i * a[-1] - np.trapz(a, grid)

def individual_rationality_ok(report_i, value_fn, payment):
    """IR check for the two-part tariff (the check left incomplete last time)."""
    return value_fn(report_i) - payment >= -1e-9
```

---

## 7. Python — the experiment that defends the paper (Fig. 1)

`rho` is **measured, not assumed**. The C++ scheduler sets `bind[i]=1` when UE i's floor is the binding constraint; Python aggregates.

```python
# sweep.py
import numpy as np
from train_frozen import L  # reuse
# loops that produce the frontier figure
ETAS = [0.4, 0.6, 0.8]          # admission-control load -> controls rho
LS   = [50, 100, 200, 400, 800] # epoch lengths

records = []
for eta in ETAS:
    for Lval in LS:
        # 1) run truthful baseline at (eta, Lval); collect per-slot bind[] -> rho_hat
        # 2) run adversary.py: one tenant Q-learns the best cross-epoch misreport
        # 3) slack = U_adv(best_misreport) - U_adv(truthful)
        # 4) learning regret vs best-fixed-weight baseline
        rho_hat = bind_count / (n_slots * n_constrained_ue)
        records.append(dict(eta=eta, L=Lval, rho=rho_hat, slack=slack, regret=regret))
np.save("frontier.npy", records)
```

```python
# adversary.py  — shows the bound is not vacuous
# A single tenant runs tabular Q-learning over a small grid of report perturbations
# {under-report, truthful, over-report} x {magnitude}, optimizing its OWN realized
# utility across epochs. Its best-found gain over truthful == measured dynamic-IC slack.
```

```python
# plot_frontier.py  — the figure
import numpy as np, matplotlib.pyplot as plt
rec = np.load("frontier.npy", allow_pickle=True)
fig, ax = plt.subplots()
for eta in sorted({r["eta"] for r in rec}):
    pts = sorted([r for r in rec if r["eta"]==eta], key=lambda r: r["L"])
    Ls   = [r["L"] for r in pts]; sl = [r["slack"] for r in pts]; rho = np.mean([r["rho"] for r in pts])
    ax.plot(Ls, sl, marker="o", label=f"rho~{rho:.2f}")
    ax.plot(Ls, [rho*max(Ls)/x for x in Ls], "--", alpha=.5)  # O(rho T/L) prediction overlay
ax.set_xlabel("epoch length L"); ax.set_ylabel("measured IC slack"); ax.legend()
# inset: rho_hat vs L per eta  -> should be ~FLAT (validates Lemma 1)
fig.savefig("fig_frontier.pdf", bbox_inches="tight")
```

---

## 8. Checklist (tick before submission)

**Theory (Day 1)**
- [ ] Lemma 1: verify $\rho$ is $L$-independent for your traffic model (the spine). If it fails, stop and tell Dibbendu.
- [ ] Theorem 2: verify the envelope-vanishing on interior slots (Appendix A KKT step).
- [ ] Theorem 3: confirm lower bound stays class-restricted; re-derive $L^\star=\Theta(\rho^{2/3}T^{1/3})$ and the $\rho^{1/3}T^{2/3}$ optimum.
- [ ] Theorem 1: confirm the inner allocator is monotone **pointwise per slot**, not just on epoch averages.

**Build (Day 2)**
- [ ] ns3-ai builds against ns-3.46 (or re-pin versions — step 1.1).
- [ ] Exact NR override method confirmed and wired (step 1.2).
- [ ] **Monotonicity unit test passes**: sweep one tenant's weight, assert its RBGs/throughput are weakly increasing (this is the DSIC guarantee in code).
- [ ] IR check passes for the two-part tariff (`mechanism.py`).
- [ ] $\rho$ logging produces sane values that move with load $\eta$.
- [ ] Keep the priority-weight symbol distinct from the scheduler's internal weights (the overloading from before).

**Experiment + figure (Day 2–3)**
- [ ] H1: slack $\propto \rho T/L$ (decreasing in $L$, scaling with $\rho$).
- [ ] H2: $\hat\rho$ flat in $L$ (the inset — this is the empirical defense of Lemma 1).
- [ ] H3: for $\rho<1$, achieved (regret, slack) beats the $\rho=1$ baseline.
- [ ] Adversary actually finds a manipulation under short $L$ (so the bound is non-vacuous).

**Writing (Day 3)**
- [ ] Fill abstract numbers, results paragraph, Fig. 1.
- [ ] Verify every bibliography entry (years, pages, DOIs — I filled from memory).
- [ ] Limitations paragraph stays honest (scalar type; sim not testbed; class-restricted lower bound).

---

## 9. The two things most likely to sink it (watch these)

1. **Lemma 1 breaks.** If longer epochs make floors bind more often (e.g., because frozen weights drift the system toward congestion within an epoch), $\rho$ depends on $L$, the second axis is illusory, and the paper degrades to "the O-RAN instantiation of Dai et al." Test this empirically *first* (H2). It is cheap and decisive.
2. **The reviewer says "ns-3 is not a testbed."** Mitigate by (a) naming 5G-LENA as 3GPP-compliant, (b) benchmarking against named baselines (PF, non-strategic RL), and (c) if at all feasible, one small OAI/srsRAN or Colosseum run. Even a single emulation point changes the conversation.
